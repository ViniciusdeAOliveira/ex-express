function imc(h, w) {
  return h / w ** 2;
}

module.exports = {
  imc,
};
